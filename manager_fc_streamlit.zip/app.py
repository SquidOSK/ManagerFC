
import random
import streamlit as st

st.set_page_config(
    page_title="Manager FC",
    page_icon="⚽",
    layout="wide",
    initial_sidebar_state="expanded",
)

CLUBE = "Manager FC"

ADVERSARIOS = [
    "Flamengo", "Palmeiras", "São Paulo", "Corinthians",
    "Santos", "Vasco", "Fluminense", "Botafogo",
    "Grêmio", "Internacional", "Cruzeiro", "Atlético-MG",
    "Bahia", "Fortaleza", "Athletico-PR", "Bragantino",
    "Ceará", "Sport", "Juventude", "Mirassol"
]

MESES = [
    "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"
]

JANELAS_TRANSFERENCIAS = [1, 2, 7, 8, 9]

JOGADORES_MERCADO = [
    {"nome": "Lucas Andrade", "posicao": "Atacante", "nivel": 82, "valor": 28_000_000, "salario": 1_800_000},
    {"nome": "Matheus Oliveira", "posicao": "Meia", "nivel": 78, "valor": 18_000_000, "salario": 1_200_000},
    {"nome": "Rafael Santos", "posicao": "Zagueiro", "nivel": 75, "valor": 12_000_000, "salario": 900_000},
    {"nome": "João Victor", "posicao": "Goleiro", "nivel": 80, "valor": 22_000_000, "salario": 1_500_000},
    {"nome": "Gabriel Rocha", "posicao": "Volante", "nivel": 73, "valor": 9_000_000, "salario": 700_000},
    {"nome": "Pedro Henrique", "posicao": "Ponta", "nivel": 85, "valor": 35_000_000, "salario": 2_300_000},
    {"nome": "Caio Martins", "posicao": "Lateral", "nivel": 77, "valor": 15_000_000, "salario": 950_000},
    {"nome": "Bruno Costa", "posicao": "Atacante", "nivel": 88, "valor": 42_000_000, "salario": 2_800_000},
    {"nome": "André Lima", "posicao": "Zagueiro", "nivel": 81, "valor": 25_000_000, "salario": 1_600_000},
    {"nome": "Felipe Alves", "posicao": "Meia", "nivel": 86, "valor": 38_000_000, "salario": 2_400_000},
]

JOGADORES_INICIAIS = [
    {"nome": "Carlos Mendes", "posicao": "Goleiro", "nivel": 74, "valor": 8_000_000, "salario": 600_000},
    {"nome": "Marcos Silva", "posicao": "Goleiro", "nivel": 71, "valor": 6_000_000, "salario": 500_000},
    {"nome": "Lucas Pereira", "posicao": "Lateral", "nivel": 73, "valor": 7_000_000, "salario": 550_000},
    {"nome": "Diego Alves", "posicao": "Lateral", "nivel": 70, "valor": 5_000_000, "salario": 450_000},
    {"nome": "Renato Souza", "posicao": "Lateral", "nivel": 75, "valor": 9_000_000, "salario": 650_000},
    {"nome": "Felipe Santos", "posicao": "Lateral", "nivel": 72, "valor": 6_500_000, "salario": 500_000},
    {"nome": "Rafael Oliveira", "posicao": "Zagueiro", "nivel": 76, "valor": 11_000_000, "salario": 700_000},
    {"nome": "Bruno Martins", "posicao": "Zagueiro", "nivel": 73, "valor": 8_000_000, "salario": 600_000},
    {"nome": "Thiago Costa", "posicao": "Zagueiro", "nivel": 78, "valor": 13_000_000, "salario": 800_000},
    {"nome": "André Souza", "posicao": "Zagueiro", "nivel": 70, "valor": 5_500_000, "salario": 450_000},
    {"nome": "Gabriel Lima", "posicao": "Volante", "nivel": 75, "valor": 10_000_000, "salario": 650_000},
    {"nome": "Pedro Souza", "posicao": "Volante", "nivel": 72, "valor": 7_000_000, "salario": 550_000},
    {"nome": "Lucas Ferreira", "posicao": "Meia", "nivel": 79, "valor": 16_000_000, "salario": 950_000},
    {"nome": "Henrique Oliveira", "posicao": "Meia", "nivel": 76, "valor": 12_000_000, "salario": 750_000},
    {"nome": "Daniel Martins", "posicao": "Meia", "nivel": 74, "valor": 9_000_000, "salario": 650_000},
    {"nome": "Eduardo Costa", "posicao": "Meia", "nivel": 71, "valor": 6_000_000, "salario": 500_000},
    {"nome": "João Pedro", "posicao": "Ponta", "nivel": 77, "valor": 14_000_000, "salario": 850_000},
    {"nome": "Gustavo Henrique", "posicao": "Ponta", "nivel": 74, "valor": 10_000_000, "salario": 700_000},
    {"nome": "Vinícius Rocha", "posicao": "Ponta", "nivel": 72, "valor": 8_000_000, "salario": 600_000},
    {"nome": "Mateus Ribeiro", "posicao": "Atacante", "nivel": 80, "valor": 20_000_000, "salario": 1_000_000},
    {"nome": "Rodrigo Alves", "posicao": "Atacante", "nivel": 76, "valor": 13_000_000, "salario": 800_000},
    {"nome": "Caio Henrique", "posicao": "Atacante", "nivel": 73, "valor": 9_000_000, "salario": 650_000},
]

def dinheiro(valor):
    sinal = "-" if valor < 0 else ""
    valor = abs(valor)
    return sinal + "R$ " + f"{valor:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")

def limitar(v):
    return max(0, min(100, v))

def criar_tabela():
    return {
        clube: {"pontos": 0, "jogos": 0, "vitorias": 0, "empates": 0, "derrotas": 0, "saldo_gols": 0}
        for clube in [CLUBE] + ADVERSARIOS
    }

def novo_jogo():
    return {
        "mes": 1,
        "saldo": 80_000_000,
        "folha": 15_000_000,
        "moral": 65,
        "desempenho": 60,
        "torcida": 60,
        "reputacao": 50,
        "vitorias": 0,
        "empates": 0,
        "derrotas": 0,
        "saldo_gols": 0,
        "elenco": [j.copy() for j in JOGADORES_INICIAIS],
        "tabela": criar_tabela(),
        "historico": [],
        "noticias": ["A temporada começou! A torcida espera uma grande campanha."],
        "encerrado": False,
    }

def aplicar(efeitos):
    t = st.session_state.time
    for atributo, valor in efeitos.items():
        t[atributo] += valor
    for atributo in ["moral", "desempenho", "torcida", "reputacao"]:
        t[atributo] = limitar(t[atributo])

def atualizar_tabela():
    t = st.session_state.time
    manager = t["tabela"][CLUBE]
    manager.update({
        "pontos": t["vitorias"] * 3 + t["empates"],
        "jogos": t["vitorias"] + t["empates"] + t["derrotas"],
        "vitorias": t["vitorias"],
        "empates": t["empates"],
        "derrotas": t["derrotas"],
        "saldo_gols": t["saldo_gols"],
    })
    for clube in ADVERSARIOS:
        d = t["tabela"][clube]
        while d["jogos"] < manager["jogos"]:
            resultado = random.choices(["vitoria", "empate", "derrota"], weights=[35, 30, 35])[0]
            d["jogos"] += 1
            if resultado == "vitoria":
                d["vitorias"] += 1
                d["pontos"] += 3
                d["saldo_gols"] += random.randint(0, 3)
            elif resultado == "empate":
                d["empates"] += 1
                d["pontos"] += 1
            else:
                d["derrotas"] += 1
                d["saldo_gols"] -= random.randint(0, 3)

def tabela_ordenada():
    atualizar_tabela()
    return sorted(
        st.session_state.time["tabela"].items(),
        key=lambda x: (x[1]["pontos"], x[1]["saldo_gols"], x[1]["vitorias"]),
        reverse=True
    )

def posicao_clube():
    for pos, (clube, _) in enumerate(tabela_ordenada(), 1):
        if clube == CLUBE:
            return pos
    return 20

def verificar_fim():
    t = st.session_state.time
    if t["saldo"] < -50_000_000:
        t["encerrado"] = True
        t["noticias"].insert(0, "🚨 O clube entrou em falência. O manager foi demitido.")
    elif t["moral"] <= 0:
        t["encerrado"] = True
        t["noticias"].insert(0, "🚨 O elenco perdeu totalmente a confiança no treinador.")
    return t["encerrado"]

def finalizar_mes():
    t = st.session_state.time
    if t["encerrado"]:
        return
    receita = 4_000_000 + t["torcida"] * 100_000 + t["reputacao"] * 50_000
    t["saldo"] -= t["folha"]
    t["saldo"] += receita
    t["historico"].append({
        "mês": MESES[t["mes"] - 1],
        "receita": receita,
        "folha": t["folha"],
        "saldo": t["saldo"]
    })
    if t["mes"] < 12:
        t["mes"] += 1
        t["noticias"].insert(0, f"📅 Novo mês: {MESES[t['mes'] - 1]}.")
    else:
        t["encerrado"] = True
        t["noticias"].insert(0, "🏆 A temporada terminou.")
    verificar_fim()

def jogar_partida():
    t = st.session_state.time
    if t["encerrado"]:
        return
    adversario = random.choice(ADVERSARIOS)
    forca_manager = t["desempenho"] + t["moral"] * 0.4 + random.randint(-20, 20)
    forca_adversario = random.randint(45, 95)

    if forca_manager > forca_adversario + 12:
        gm, ga = random.randint(2, 4), random.randint(0, 1)
        t["vitorias"] += 1
        t["saldo"] += 2_000_000
        t["moral"] += 5
        t["desempenho"] += 2
        texto = f"🏆 Vitória: {CLUBE} {gm} x {ga} {adversario}"
    elif forca_manager >= forca_adversario - 8:
        gm = random.randint(0, 2)
        ga = gm
        t["empates"] += 1
        t["saldo"] += 800_000
        t["moral"] += 1
        texto = f"🤝 Empate: {CLUBE} {gm} x {ga} {adversario}"
    else:
        gm, ga = random.randint(0, 1), random.randint(2, 4)
        t["derrotas"] += 1
        t["moral"] -= 6
        t["desempenho"] -= 2
        texto = f"❌ Derrota: {CLUBE} {gm} x {ga} {adversario}"

    t["saldo_gols"] += gm - ga
    aplicar({})
    t["noticias"].insert(0, texto)
    atualizar_tabela()
    verificar_fim()

def contratar(nome):
    t = st.session_state.time
    if t["mes"] not in JANELAS_TRANSFERENCIAS:
        st.warning("A janela de transferências está fechada.")
        return
    jogador = next((j for j in JOGADORES_MERCADO if j["nome"] == nome), None)
    if not jogador:
        return
    if any(j["nome"] == nome for j in t["elenco"]):
        st.warning("Este jogador já está no elenco.")
        return
    if t["saldo"] < jogador["valor"]:
        st.error("Dinheiro insuficiente para contratar este jogador.")
        return
    t["saldo"] -= jogador["valor"]
    t["folha"] += jogador["salario"]
    t["elenco"].append(jogador.copy())
    aumento = max(1, (jogador["nivel"] - 70) // 2)
    t["desempenho"] += aumento
    t["torcida"] += random.randint(2, 8)
    t["reputacao"] += random.randint(1, 5)
    aplicar({})
    t["noticias"].insert(0, f"🔄 {nome} foi contratado por {dinheiro(jogador['valor'])}.")

def decisao_evento(tipo, escolha):
    t = st.session_state.time
    eventos = {
        "patrocinador": [
            ("Aceitar o contrato", {"saldo": 12_000_000, "reputacao": 2}, "O clube recebeu R$ 12 milhões."),
            ("Exigir valor maior", {"saldo": 20_000_000, "reputacao": 4}, "Excelente negociação! O patrocinador aceitou."),
            ("Recusar", {"saldo": -2_000_000, "reputacao": -2}, "O clube perdeu uma oportunidade."),
            ("Aceitar com bônus por desempenho", {"saldo": 7_000_000, "desempenho": 3, "reputacao": 3}, "Contrato com bônus fechado."),
            ("Leiloar o espaço da camisa", {"saldo": 28_000_000, "torcida": -3}, "A receita aumentou, mas parte da torcida reclamou."),
        ],
        "base": [
            ("Investir R$ 10 milhões", {"saldo": -10_000_000, "desempenho": 8, "reputacao": 6}, "Um jovem talento foi descoberto."),
            ("Investir R$ 5 milhões", {"saldo": -5_000_000, "desempenho": 4, "reputacao": 2}, "A base recebeu melhorias moderadas."),
            ("Investir R$ 1 milhão", {"saldo": -1_000_000, "desempenho": 1}, "Investimento pequeno, mas útil."),
            ("Não investir", {"saldo": 3_000_000, "reputacao": -5}, "O clube economizou, mas perdeu prestígio."),
            ("Vender direitos de um jovem", {"saldo": 15_000_000, "desempenho": -3, "reputacao": -4}, "O clube recebeu dinheiro, mas perdeu um possível talento."),
        ],
        "estadio": [
            ("Reforma completa", {"saldo": -35_000_000, "torcida": 15, "reputacao": 10}, "O estádio ficou moderno."),
            ("Reformar vestiários", {"saldo": -8_000_000, "moral": 5, "reputacao": 2}, "Os jogadores aprovaram as instalações."),
            ("Melhorar setores populares", {"saldo": -12_000_000, "torcida": 10}, "A torcida aprovou a melhoria."),
            ("Adiar reforma", {"saldo": 2_000_000, "torcida": -3}, "O clube economizou, mas a torcida reclamou."),
            ("Construir camarotes", {"saldo": 18_000_000, "torcida": -5, "reputacao": 3}, "Novos patrocinadores foram atraídos."),
        ],
        "divida": [
            ("Pagar toda a dívida", {"saldo": -20_000_000, "reputacao": 8}, "A dívida foi quitada."),
            ("Parcelar a dívida", {"saldo": -5_000_000, "reputacao": 2}, "A dívida foi parcelada."),
            ("Contestar na Justiça", {"saldo": 3_000_000, "reputacao": -5}, "O clube ganhou tempo, mas perdeu reputação."),
            ("Pedir empréstimo", {"saldo": 15_000_000, "folha": 500_000, "reputacao": -2}, "A emergência foi resolvida, mas os custos aumentaram."),
            ("Vender direitos comerciais", {"saldo": 25_000_000, "torcida": -4, "reputacao": -3}, "A dívida foi controlada."),
        ],
    }
    opcoes = eventos[tipo]
    efeitos, resultado = opcoes[escolha][1], opcoes[escolha][2]
    aplicar(efeitos)
    t["noticias"].insert(0, "📰 " + resultado)
    verificar_fim()

def evento_aleatorio():
    return random.choice(["patrocinador", "base", "estadio", "divida"])

def evento_titulo(tipo):
    return {
        "patrocinador": ("NOVO PATROCINADOR", "Uma empresa quer patrocinar o Manager FC."),
        "base": ("CATEGORIAS DE BASE", "A diretoria precisa decidir quanto investir na base."),
        "estadio": ("REFORMA DO ESTÁDIO", "O estádio precisa de melhorias."),
        "divida": ("DÍVIDA INESPERADA", "Uma dívida antiga do clube foi cobrada."),
    }[tipo]

def render_header():
    t = st.session_state.time
    st.markdown(f"""
    <div class="hero">
        <div>
            <h1>⚽ {CLUBE}</h1>
            <p>Brasileirão • {MESES[t['mes']-1]} • Temporada em andamento</p>
        </div>
        <div class="hero-money">{dinheiro(t['saldo'])}</div>
    </div>
    """, unsafe_allow_html=True)

def metricas():
    t = st.session_state.time
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("🏆 Posição", f"{posicao_clube()}º")
    c2.metric("💰 Saldo", dinheiro(t["saldo"]))
    c3.metric("💪 Moral", f"{t['moral']}/100")
    c4.metric("📈 Desempenho", f"{t['desempenho']}/100")
    c5.metric("👥 Elenco", len(t["elenco"]))

def pagina_visao():
    t = st.session_state.time
    st.subheader("📊 Visão geral")
    metricas()

    c1, c2 = st.columns([1.3, 1])
    with c1:
        st.markdown("### Próxima ação")
        if t["encerrado"]:
            st.error("A temporada está encerrada.")
        else:
            st.info(f"Estamos em **{MESES[t['mes']-1]}**. Escolha uma ação na barra lateral.")
            if st.button("⚽ Jogar próxima partida", use_container_width=True):
                jogar_partida()
                st.rerun()
            if st.button("📅 Encerrar mês", use_container_width=True):
                finalizar_mes()
                st.rerun()

    with c2:
        st.markdown("### Últimas notícias")
        for n in t["noticias"][:6]:
            st.write(n)

    st.markdown("### 📋 Campanha")
    st.write(f"**{t['vitorias']} vitórias** • **{t['empates']} empates** • **{t['derrotas']} derrotas** • **Saldo de gols: {t['saldo_gols']:+d}**")

def pagina_elenco():
    t = st.session_state.time
    st.subheader("👥 Elenco do Manager FC")
    filtro = st.selectbox("Filtrar por posição", ["Todas", "Goleiro", "Lateral", "Zagueiro", "Volante", "Meia", "Ponta", "Atacante"])
    jogadores = t["elenco"] if filtro == "Todas" else [j for j in t["elenco"] if j["posicao"] == filtro]
    st.caption(f"{len(jogadores)} jogador(es) exibido(s) • {len(t['elenco'])} no elenco")

    for j in jogadores:
        col1, col2, col3, col4, col5 = st.columns([2.2, 1.2, .8, 1.5, 1.3])
        col1.write(f"**{j['nome']}**")
        col2.write(j["posicao"])
        col3.write(f"**{j['nivel']}**")
        col4.write(dinheiro(j["valor"]))
        col5.write(dinheiro(j["salario"]))
        st.progress(j["nivel"] / 100)

def pagina_mercado():
    t = st.session_state.time
    st.subheader("🔄 Mercado de transferências")
    if t["mes"] not in JANELAS_TRANSFERENCIAS:
        st.warning("Janela fechada. Contratações: janeiro, fevereiro, julho, agosto e setembro.")
    else:
        st.success("Janela de transferências aberta.")

    nomes = {j["nome"] for j in t["elenco"]}
    disponiveis = [j for j in JOGADORES_MERCADO if j["nome"] not in nomes]
    filtro = st.selectbox("Posição", ["Todas", "Goleiro", "Lateral", "Zagueiro", "Volante", "Meia", "Ponta", "Atacante"], key="mercado_pos")
    disponiveis = disponiveis if filtro == "Todas" else [j for j in disponiveis if j["posicao"] == filtro]

    for j in disponiveis:
        with st.container(border=True):
            a, b, c, d, e = st.columns([2.1, 1, .7, 1.4, 1])
            a.write(f"**{j['nome']}**")
            b.write(j["posicao"])
            c.write(f"Nível **{j['nivel']}**")
            d.write(dinheiro(j["valor"]))
            if e.button("Contratar", key="contratar_" + j["nome"]):
                contratar(j["nome"])
                st.rerun()

def pagina_tabela():
    st.subheader("🏆 Brasileirão")
    linhas = []
    for pos, (clube, d) in enumerate(tabela_ordenada(), 1):
        linhas.append({
            "POS": pos, "CLUBE": clube, "P": d["pontos"], "J": d["jogos"],
            "V": d["vitorias"], "E": d["empates"], "D": d["derrotas"], "SG": d["saldo_gols"]
        })
    st.dataframe(linhas, use_container_width=True, hide_index=True)

def pagina_financas():
    t = st.session_state.time
    st.subheader("💰 Finanças")
    c1, c2, c3 = st.columns(3)
    c1.metric("Saldo", dinheiro(t["saldo"]))
    c2.metric("Folha salarial", dinheiro(t["folha"]))
    c3.metric("Valor do elenco", dinheiro(sum(j["valor"] for j in t["elenco"])))
    if t["historico"]:
        st.markdown("### Histórico mensal")
        st.dataframe(t["historico"], use_container_width=True, hide_index=True)

def pagina_decisoes():
    t = st.session_state.time
    st.subheader("📰 Decisão administrativa")
    tipo = st.selectbox("Evento", ["patrocinador", "base", "estadio", "divida"], format_func=lambda x: evento_titulo(x)[0])
    titulo, texto = evento_titulo(tipo)
    st.info(f"**{titulo}** — {texto}")
    opcoes = {
        "patrocinador": ["Aceitar o contrato", "Exigir valor maior", "Recusar", "Aceitar com bônus por desempenho", "Leiloar o espaço da camisa"],
        "base": ["Investir R$ 10 milhões", "Investir R$ 5 milhões", "Investir R$ 1 milhão", "Não investir", "Vender direitos de um jovem"],
        "estadio": ["Reforma completa", "Reformar vestiários", "Melhorar setores populares", "Adiar reforma", "Construir camarotes"],
        "divida": ["Pagar toda a dívida", "Parcelar a dívida", "Contestar na Justiça", "Pedir empréstimo", "Vender direitos comerciais"],
    }[tipo]
    escolha = st.radio("Escolha uma decisão:", opcoes)
    if st.button("Confirmar decisão", type="primary", use_container_width=True):
        decisao_evento(tipo, opcoes.index(escolha))
        st.success("Decisão aplicada.")
        st.rerun()

def pagina_moral():
    st.subheader("💪 Gestão do elenco")
    opcoes = [
        ("Oferecer bônus ao elenco.", {"saldo": -6_000_000, "moral": 15, "desempenho": 3}, "O elenco ficou muito motivado."),
        ("Organizar um jantar.", {"saldo": -800_000, "moral": 8}, "O jantar aproximou os jogadores."),
        ("Cobrar mais dedicação.", {"moral": -5, "desempenho": 8}, "O rendimento nos treinos aumentou."),
        ("Dar folga ao elenco.", {"moral": 10, "desempenho": -4}, "O elenco descansou, mas perdeu ritmo."),
        ("Prometer prêmio por título.", {"saldo": -10_000_000, "moral": 12, "desempenho": 4}, "O elenco ficou motivado."),
    ]
    escolha = st.radio("Escolha uma ação:", [x[0] for x in opcoes])
    if st.button("Aplicar", type="primary", use_container_width=True):
        item = opcoes[[x[0] for x in opcoes].index(escolha)]
        aplicar(item[1])
        st.session_state.time["noticias"].insert(0, "💪 " + item[2])
        verificar_fim()
        st.rerun()

def pagina_temporada():
    t = st.session_state.time
    st.subheader("🏁 Resultado da temporada")
    if not t["encerrado"] or t["mes"] < 12:
        st.info("A temporada ainda está em andamento.")
        return
    pos = posicao_clube()
    pontos = t["vitorias"] * 3 + t["empates"]
    st.metric("Colocação final", f"{pos}º lugar")
    st.metric("Pontuação", pontos)
    if pos == 1:
        st.success("🏆 CAMPEÃO BRASILEIRO!")
    elif pos <= 4:
        st.success("🌎 Vaga garantida na Libertadores!")
    elif pos <= 8:
        st.info("🌎 Boa campanha e vaga continental!")
    elif pos <= 16:
        st.info("🇧🇷 O Manager FC permaneceu na Série A.")
    else:
        st.error("⬇️ O Manager FC foi rebaixado.")

# CSS
st.markdown("""
<style>
.hero {
    padding: 22px 28px;
    border-radius: 18px;
    margin-bottom: 18px;
    background: linear-gradient(135deg, #101827, #172554);
    color: white;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.hero h1 { margin: 0; font-size: 2.1rem; }
.hero p { margin: 5px 0 0; opacity: .75; }
.hero-money { font-size: 1.7rem; font-weight: 700; }
[data-testid="stMetric"] {
    border: 1px solid rgba(128,128,128,.25);
    padding: 14px;
    border-radius: 14px;
}
</style>
""", unsafe_allow_html=True)

if "time" not in st.session_state:
    st.session_state.time = novo_jogo()

t = st.session_state.time
render_header()

with st.sidebar:
    st.title("⚽ Manager FC")
    st.caption("Painel do treinador")
    pagina = st.radio(
        "Navegação",
        ["📊 Visão geral", "👥 Elenco", "🔄 Mercado", "🏆 Brasileirão", "💰 Finanças", "📰 Decisões", "💪 Moral", "🏁 Temporada"]
    )
    st.divider()
    st.write(f"**Mês:** {MESES[t['mes']-1]}")
    st.write(f"**Posição:** {posicao_clube()}º")
    if st.button("🔄 Reiniciar temporada", use_container_width=True):
        st.session_state.time = novo_jogo()
        st.rerun()

if pagina == "📊 Visão geral":
    pagina_visao()
elif pagina == "👥 Elenco":
    pagina_elenco()
elif pagina == "🔄 Mercado":
    pagina_mercado()
elif pagina == "🏆 Brasileirão":
    pagina_tabela()
elif pagina == "💰 Finanças":
    pagina_financas()
elif pagina == "📰 Decisões":
    pagina_decisoes()
elif pagina == "💪 Moral":
    pagina_moral()
else:
    pagina_temporada()
