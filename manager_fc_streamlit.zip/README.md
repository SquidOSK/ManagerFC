# Manager FC — versão Web

## Como rodar no Chromebook

1. Abra um ambiente Python online, como o Replit.
2. Crie um projeto Python.
3. Coloque `app.py` e `requirements.txt` no projeto.
4. Instale as dependências:
   `pip install -r requirements.txt`
5. Execute:
   `streamlit run app.py`

A aplicação abrirá uma interface web que pode ser usada diretamente no navegador do Chromebook.

## O que já está incluído

- Interface gráfica responsiva
- Painel do clube
- Elenco inicial com 22 jogadores
- Nível, posição, valor de mercado e salário
- Mercado de transferências
- Brasileirão com tabela
- Finanças
- Decisões administrativas
- Gestão de moral
- Partidas
- Notícias
- Histórico financeiro
- Resultado da temporada
